package recap2;

import java.util.Scanner;

public class Q06_StringManipulation {
    //Scanner kullanarak iki ayri deger giriniz ve bu iki kelimeyi method kullanarak birlestiriniz.

    //yukardaki ornekte verilen ilk ve ikinci degiskenlerinin ilk harflerini atip birlestiriniz.

    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.print("Kelime 1: ");
        String kelime1=scan.next();
        System.out.print("Kelime 2: ");
        String kelime2=scan.next();

       String sonuc1=kelime1.concat(kelime2);
       System.out.println("Methodla birlesmis hali: " + sonuc1);

      String sonuc2=kelime1.substring(1)+kelime2.substring(1);
        System.out.println("İkinci birlestirme : " + sonuc2);




    }
}
