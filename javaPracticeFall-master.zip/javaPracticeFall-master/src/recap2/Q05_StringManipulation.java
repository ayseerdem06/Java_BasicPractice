package recap2;

import java.util.Scanner;

public class Q05_StringManipulation {
    //Kullanicidan ismini ve soyisimi girmesini isteyin,
    // sonrasinda konsola tam ismini buyuk harfler ile yazdirin

    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.print("isim girin : ");
        String name= scan.nextLine();
        System.out.print("Soyisim girin : ");
        String surname= scan.nextLine();

        System.out.println("İsim soyisim: "+ name.toUpperCase()+ " " + surname);

    }
}
