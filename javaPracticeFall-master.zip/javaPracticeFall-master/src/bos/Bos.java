package bos;

import java.util.Scanner;

public class Bos {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("boyunuzu giriniz");
        double boy=scan.nextDouble();
        System.out.println("kilonuzu giriniz");
        double kilo= scan.nextDouble()/100;
        double bmi= scan.nextDouble();
        bmi=kilo/(boy*boy);
        if (bmi<=20) {
            System.out.println("zayifsinız");
        }
        else if(bmi<=25){
            System.out.println("normal sınırdasınız");
        }
        else if (bmi<=30){
            System.out.println("sismansnız");
        }
        else if (bmi<=30){
            System.out.println("obez");
        }
        else{
            System.out.println("geçerli bir değer giriniz");
        }
    }

    }

